# Piramide Uploader a very simple class to upload files in PHP
